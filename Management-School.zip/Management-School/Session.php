<!-- -->
<?php
  include "database/db.php";


if (isset($_SESSION['userId']) && $_SESSION['userId'] != null && isset($_SESSION['Role']) && $_SESSION['Role'] != null) {
    $role = $_SESSION['Role'];
    $User_id  = $_SESSION['userId'];

    $query = "SELECT * FROM tblregister WHERE User_Id=$User_id ;"; 
    $rs = $conn->query($query);
    $num = $rs->num_rows;
    $row = $rs->fetch_assoc();
    // Admin 
    if($role == "Admin"){
 
       $qu = "SELECT * FROM tbladmin WHERE Id =$User_id ";
       $rs = $conn->query($qu);
       $number = $rs->num_rows;
       $rows = $rs->fetch_assoc();
       if($number > 0){
 
         $_SESSION['userId'] = $rows['Id'];
         $_SESSION['firstName'] = $rows['firstName'];
         $_SESSION['lastName'] = $rows['lastName'];
         $_SESSION['emailAddress'] = $rows['emailAddress'];
         $_SESSION['Role'] = $role;
         $_SESSION['image_Id'] = $row['Id'];
         
         if($row['Verification'] == 1){
           echo "<script type = \"text/javascript\">
           window.location = (\"Admin(directeur)/Admin/index.php\")
           </script>";
         }else{
           echo "<script type = \"text/javascript\">
                 window.location = (\"Verification.php \")
                 </script>";
         }
       }
   }
   // Teacher 
   if($role == "Teacher"){
 
       $qu = "SELECT * FROM tblclassteacher WHERE Id =$User_id ;";
       $rs = $conn->query($qu);
       $number = $rs->num_rows;
       $rows = $rs->fetch_assoc();
       if($number > 0){
         $_SESSION['userId'] = $rows['Id'];
         $_SESSION['firstName'] = $rows['firstName'];
         $_SESSION['lastName'] = $rows['lastName'];
         $_SESSION['emailAddress'] = $rows['emailAddress'];
         $_SESSION['Role'] = $role;
         $_SESSION['image_Id'] = $row['Id'];
 
         if($row['Verification'] == 1){
           echo "<script type = \"text/javascript\">
           window.location = (\"Teacher/teacher/index.php \")
           </script>";
         }else{
           echo "<script type = \"text/javascript\">
                 window.location = (\"Verification.php \")
                 </script>";
         }
       }
   }
   // Student  	Student
   if($role == "Student"){
 
     $qu = "SELECT * FROM tblstudents WHERE Id=$User_id ;";
     $rs = $conn->query($qu);
     $number = $rs->num_rows;
     $rows = $rs->fetch_assoc();
     if($number > 0){
       $_SESSION['userId'] = $rows['Id'];
       $_SESSION['firstName'] = $rows['firstName'];
       $_SESSION['lastName'] = $rows['lastName'];
       $_SESSION['emailAddress'] = $rows['Email'];
       $_SESSION['Role'] = $role;
       $_SESSION['image_Id'] = $row['Id'];
  
         if($row['Verification'] == 1){
           echo "<script type = \"text/javascript\">
           window.location = (\"Student/index.php \")
           </script>";
         }else{
           echo "<script type = \"text/javascript\">
                 window.location = (\"Verification.php \")
                 </script>";
         }
       }
    }
 }
?>
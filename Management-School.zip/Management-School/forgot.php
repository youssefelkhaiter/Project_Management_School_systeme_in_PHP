 <!-- -->
  <!-- -->
  <?php
 error_reporting(0);
  // connection db 
  include "database/db.php";
  // session start
  session_start();
  include "Session.php";

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Forgot</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/university-student-graduation-png-22.png" rel="icon">
  <link href="assets/img/university-student-graduation-png-22.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
  
</head>
<style>

    #code{
              display: none;
          }

     #login{
        display: none;
     }

    .rounded-t-5 {
      border-top-left-radius: 0.5rem;
      border-top-right-radius: 0.5rem;
    }

    @media (min-width: 992px) {
      .rounded-tr-lg-0 {
        border-top-right-radius: 0;
      }

      .rounded-bl-lg-5 {
        border-bottom-left-radius: 0.5rem;
      }
    }
    #content-wrapper{
        height: 100vh;
    }
    #alert{
        opacity: 0.0;
    }


    .form-outline .field{
          position: relative;
          height: 50px;
          width: 100%;
          margin-top: 20px;
          border-radius: 6px;
      }
      .form-outline .field #input,
      .form-outline .field #password{
          height: 100%;
          width: 100%;
          border: none;
          font-size: 16px;
          font-weight: 400;
          border-radius: 6px;
      }
      .form-outline .field #input,
      .form-outline .field #password{
          outline: none;
          padding: 0 15px;
          border: 1px solid#CACACA;
      }
      .form-outline .field #input:focus,
      .form-outline .field #password:focus{
          border-bottom-width: 2px;
      }
      .form-outline .eye-icon{
          position: absolute;
          top: 50%;
          right: 10px;
          transform: translateY(-50%);
          font-size: 18px;
          color: #8b8b8b;
          cursor: pointer;
          padding: 5px;
          
      }


  </style>
<body id="page-top">
    <div id="content-wrapper" style="background-color: #003566;" class="d-flex flex-column">
      <div id="content" >
        <!-- TopBar -->
        <?php include "includes/header.php";?>
        <!-- Topbar -->
        <!-- ======= Breadcrumbs ======= -->
        <div class="breadcrumbs">
          <div class="page-header d-flex align-items-center" style="background-image: url('assets/img/cert2.webp');">
            <div class="container position-relative">
              <div class="row d-flex justify-content-center">
                <div class="col-lg-6 text-center">
                  <h2>Forgot</h2>
                  <p>
                    <br>
                    <br>
                    <br>
                    <br>
                  </p>
                </div>
              </div>
            </div>
          </div>
          
        </div>
        <!-- End Breadcrumbs -->
            <section class="text-center" >
            <!-- Background image -->
            
            </div>
            <!-- Background image -->

            <div class="card mx-4 mx-md-5 shadow-5-strong" style="
                    margin-top: -300px;
                    background: hsla(0, 0%, 100%, 0.6);
                    backdrop-filter: blur(30px);
                    ">
                <div class="card-body py-5 px-md-5">

                <div class="row d-flex justify-content-center">
                    <div class="col-lg-6">
                    <h2 class="fw-bold " style="font-family: Georgia, serif;font-size: 2.6em;letter-spacing: 2px;">Forgot</h2>

                    <!-- check Email -->
                    <form method="POST" id="check">
                      
                        <div class="form-outline mb-4">
                          <div class="field input-field">
                            <input type="email" id="input" name="email" placeholder="Check your Email" class="form-control" required />
                          </div>
                        </div>

                        <div class="row mb-4">
                            <div class="col d-flex justify-content-center">
                              <span>For Login  <a href="loginup.php">Click Here</a></span>
                                
                            </div>
                        </div>

                        <!-- Submit button -->
                        <button type="submit" name="forgot" style="font-family: Georgia, serif;font-size: 1.2em;letter-spacing: 2px;padding:5px 25px;"  class="btn btn-primary btn-block mb-2">
                        Check
                        </button>

                    </form>

                    
                  <p class="alert alert-danger" id="alert" >
                      The Email Is Wrong
                  </p>

<?php 

if(isset($_POST['forgot'])){

    if(isset($_POST['email']) ){

      $email = mysqli_real_escape_string($conn,$_POST['email']);

      $query = "SELECT * FROM tblregister WHERE Email = '$email' "; 
      $rs = $conn->query($query);
      $num = $rs->num_rows;
      $rows = $rs->fetch_assoc();

      if($num > 0){

        
        echo '<style>
                #code{
                  display: inline;
                }
                #check{
                  display: none;
              }
              </style>';

              include "email/index.php";
              
              if(isset($_POST['forgot'])){

                $From = 'tt3486667@gmail.com';
                $name = 'Welcome to Management School ';

                //$email = mysqli_real_escape_string($conn,$_POST['emai']); // $email
                $fullname = mysqli_real_escape_string($conn,$rows['Fname'].' , '.$rows['Lname']);  
                //Recipients
                $mail->setFrom($From, $name);
                $mail->addAddress($email, $fullname );     //Add a recipient

                //Content
                $mail->isHTML(true);                                  //Set email format to HTML
                $mail->Subject = 'Verification Code ';
                //$mail->msgHTML(file_get_contents("email-content.html"), __DIR__);

                $time = time();
                $mail->Body ="Code is : ".$time."<br> Enter this's Message Code";
                //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

                
                if($mail->send()){

                  // UPDATE `tblregister` SET `veri_code` = '11' WHERE tblregister. Id = 1;
                  $query_check_email = "UPDATE tblregister SET veri_code = $time WHERE Email = '$email' "; 
                  $rs_email = $conn->query($query_check_email);
     
                  if($rs_email){
                    echo '<p  class="alert alert-primary" role="alert"  >
                              Message has been sent checked your Email
                        </p>';
                  }
                 
                }else{
                  echo '<p class="alert alert-danger" >
                          Message is not sent. Error is : '.$mail->ErrorInfo.'
                        </p>';
                }
                
              }
    

      }
      else{
        echo '<style>
                #alert{
                    opacity: 0.9;
                }

              </style>';
            
      }

    }
    
}

?>
<!-- Code -->
<form method="POST" id="code">

<div class="form-outline mb-3">
      <div class="field input-field">
        <input style="cursor: default;" type="email" id="input" name="check_email" value="<?php echo $email; ?>" class="form-control" required />
      </div>
    </div>
  <div class="form-outline mb-3">
      <div class="field input-field">
          <input type="number" id="input" name="Code" placeholder="Enter your Code" class="form-control" required />
      </div>
  </div>

    <div class="row mb-4">
        <div class="col d-flex justify-content-center">
          <span>For Login  <a href="loginup.php">Click Here</a></span>
        </div>
    </div>


    <!-- Submit button -->
    <button type="submit" name="verifi_code" style="font-family: Georgia, serif;font-size: 1.2em;letter-spacing: 2px;padding:5px 25px;"  class="btn btn-primary btn-block mb-2">
    Check
    </button>

</form>
<?php 

if(isset($_POST['verifi_code'])){
  $email = mysqli_real_escape_string($conn,$_POST['check_email']);
  $Code = mysqli_real_escape_string($conn,$_POST['Code']);
   
  $query_email = "SELECT * FROM tblregister WHERE Email = '$email' "; 
  $rse = $conn->query($query_email);
  $numbre = $rse->num_rows;
  $row = $rse->fetch_assoc();

  if($numbre > 0){

    if($Code == mysqli_real_escape_string($conn,$row['veri_code'])){

      // $query_uptate = "UPDATE tblregister SET veri_code = 1 WHERE Email = '$email' "; 
      // $conn->query($query_uptate);
      $query=mysqli_query($conn,"UPDATE tblregister SET Verification=0, veri_code=1 WHERE User_Id=".$row['Id']." ;");

      if( $query){
        $_SESSION['userId'] = $row['Id'];
        $_SESSION['firstName'] = $row['Fname'];
        $_SESSION['lastName'] = $row['Lname'];
        $_SESSION['emailAddress'] = $row['Email'];
        $_SESSION['Role'] = $row['Role'];
        $_SESSION['image_Id'] = $row['Id'];

        echo "<script type = \"text/javascript\">
              window.location = (\"Verification.php\")
              </script>";
      }
      
    }else{
      echo '<p class="alert alert-danger" >
            The Code Is Wrong
            </p>';
    }


  }else{
    echo '<p class="alert alert-danger" >
          The Email Is Wrong
          </p>';
  }
}

?>
                        <!-- Register buttons -->
                        <div class="text-center">
                         <span  style="font-family: Georgia, serif;font-size: 1.2em;color:#000;letter-spacing: 1px;" >
                         Get connected with us on social networks
                         </span>   
                        <button type="button"class="btn btn-link btn-floating mx-1">
                            <i style="font-size: 1.5em;" class="fab fa-facebook-f"></i>
                        </button>

                        <button type="button" class="btn btn-link btn-floating mx-1">
                            <i style="font-size: 1.5em;" class="fab fa-google"></i>
                        </button>

                        <button type="button" class="btn btn-link btn-floating mx-1">
                            <i style="font-size: 1.5em;" class="fab fa-twitter"></i>
                        </button>

                        <button type="button" class="btn btn-link btn-floating ">
                            <i style="font-size: 1.5em;" class="fab fa-github"></i>
                        </button>
                        </div>
                    
                    </div>
                </div>
            </div>
            </section>
<!-- Section: Design Block -->
        <!---Container Fluid-->
      </div>
      <!-- Footer -->
      <?php // include "include/footer.php"; ?>
      <!-- Footer -->
    
  </div>

  <!-- Scroll to top -->
 <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>


  <!-- Page level custom scripts -->
  <script>
     $(document).ready(function () {
        $('#dataTable').DataTable(); // ID From dataTable
        $('#dataTableHover').DataTable(); // ID From dataTable with Hover
     });

  </script>
  <a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<div id="preloader"></div>

<!-- Vendor JS Files -->
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
<script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="assets/vendor/aos/aos.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>

<!-- Template Main JS File -->
<script src="assets/js/main.js"></script>

</body>

</html>
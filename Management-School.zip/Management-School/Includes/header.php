<style>
  
    ::-webkit-scrollbar {
      width: 10px; 
    }
    ::-webkit-scrollbar-thumb {
      background-color: #023047;
      border-radius: 4px;
    }

    ::-webkit-scrollbar-track {
      background-color: #f1f1f1; 
    }
 </style>
 
 <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="index.php" class="logo d-flex align-items-center">
        <!-- <img src="assets/img/university-student-graduation-png-22.png" alt="Image"> -->
        <h1>
          <i class="fa-solid fa-graduation-cap"></i>
        </h1>
      </a>

      <i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
      <i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>
      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="index.php" class="active-Home">Home</a></li>
          <li><a href="about.php" class="active-About">About</a></li>
          <li><a href="news.php" class="active-News">News</a></li>
          <li><a href="services.php" class="active-Services">Services</a></li>
          <li><a href="pricing.php" class="active-Pricing">Pricing</a></li>
          <li class="dropdown"><a href="#" class="active-Trainings"><span>Trainings</span> <i class="bi bi-chevron-down dropdown-indicator"></i></a>
            <ul>
                <li><a href="Professional_training.php">Professional training</a></li>
                <li><a href="Higher_education.php">Higher education</a></li>
                <li><a href="Continuing_Education.php">Continuing Education</a></li>
            </ul>
          </li>
          <li><a href="contact.php" class="active-Contact">Contact</a></li>
          <li><a class="get-a-quote" href="loginup.php">Login up</a></li>
        </ul>
      </nav>
      <!-- .navbar -->

    </div>
  </header>
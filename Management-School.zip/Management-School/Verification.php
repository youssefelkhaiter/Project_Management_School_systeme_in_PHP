<!-- -->
<?php
  
  error_reporting(0);
  // connection db 
  include "database/db.php";
    // session start
    session_start();
    // include "Session.php";
    
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>News</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/university-student-graduation-png-22.png" rel="icon">
  <link href="assets/img/university-student-graduation-png-22.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
  
</head>
<style>
     #login{
        display: none;
     }

    .rounded-t-5 {
      border-top-left-radius: 0.5rem;
      border-top-right-radius: 0.5rem;
    }

    @media (min-width: 992px) {
      .rounded-tr-lg-0 {
        border-top-right-radius: 0;
      }

      .rounded-bl-lg-5 {
        border-bottom-left-radius: 0.5rem;
      }
    }
    #content-wrapper{
        height: 100vh;
    }
    #alert{
        opacity: 0.0;
    }
    .form-outline .field{
          position: relative;
          height: 50px;
          width: 100%;
          margin-top: 20px;
          border-radius: 6px;
      }
      .form-outline .field #input,
      .form-outline .field #password{
          height: 100%;
          width: 100%;
          border: none;
          font-size: 16px;
          font-weight: 400;
          border-radius: 6px;
      }
      .form-outline .field #input,
      .form-outline .field #password{
          outline: none;
          padding: 0 15px;
          border: 1px solid#CACACA;
      }
      .form-outline .field #input:focus,
      .form-outline .field #password:focus{
          border-bottom-width: 2px;
      }
      .form-outline .eye-icon{
          position: absolute;
          top: 50%;
          right: 10px;
          transform: translateY(-50%);
          font-size: 18px;
          color: #8b8b8b;
          cursor: pointer;
          padding: 5px;
      }


  </style>
<body id="page-top">
    <div id="content-wrapper" style="background-color: #003566;" class="d-flex flex-column">
      <div id="content" >
        <!-- TopBar -->
        <?php include "includes/header.php";?>
        <!-- Topbar -->
        <!-- ======= Breadcrumbs ======= -->
        <div class="breadcrumbs">
          <div class="page-header d-flex align-items-center" style="background-image: url('assets/img/cert2.webp');">
            <div class="container position-relative">
              <div class="row d-flex justify-content-center">
                <div class="col-lg-6 text-center">
                  <h2>Forgot</h2>
                  <p>
                    <br>
                    <br>
                    <br>
                    <br>
                  </p>
                </div>
              </div>
            </div>
          </div>
          
        </div>
        <!-- End Breadcrumbs -->
            <section class="text-center" >
            <!-- Background image -->
            
            </div>
            <!-- Background image -->

            <div class="card mx-4 mx-md-5 shadow-5-strong" style="
                    margin-top: -300px;
                    background: hsla(0, 0%, 100%, 0.6);
                    backdrop-filter: blur(30px);
                    ">
                <div class="card-body py-5 px-md-5">

                <div class="row d-flex justify-content-center">
                    <div class="col-lg-6">
                    <form method="POST">
                        <!-- Password input -->
                        <div class="form-outline mb-4">
                          <label class="form-label" style="font-family: Georgia, serif;font-size: 1.5em;letter-spacing: 1px;">New Password</label>
                          <div class="field input-field mb-2">
                              <input type="password" placeholder="Enter Your New Password " id="password" name="NewPassword1" class="form-control" required />
                              <i class='bx bx-hide eye-icon'></i>
                          </div>
                        </div>
                        <!-- Password input -->
                        <div class="form-outline mb-4">
                          <label class="form-label" style="font-family: Georgia, serif;font-size: 1.5em;letter-spacing: 1px;">Confirme Password</label>
                          <div class="field input-fieldmb-2">
                              <input type="password" placeholder="Enter Your New Password Verification" id="password" name="NewPassword2" class="form-control" required />
                              <i class='bx bx-hide eye-icon'></i>
                          </div>
                        </div>

                        <!-- Submit button -->
                        <button type="submit" onclick="verifi()" name="SaveVerifecation" style="font-family: Georgia, serif;font-size: 1.2em;letter-spacing: 2px;padding:5px 25px;"  class="btn btn-primary btn-block m-2">
                            Verification Password
                        </button>

                    
            <p class="alert alert-danger" id="alert" >
                Verifi this is Password 
            </p>

<?php 

    if(isset($_POST['SaveVerifecation']) && isset($_SESSION['Role']) && $_SESSION['Role'] != null)
    {
      $pwd1 = mysqli_real_escape_string($conn,$_POST['NewPassword1']);
      $pwd2 = mysqli_real_escape_string($conn,$_POST['NewPassword2']);
     
        if($pwd1 == $pwd2){
            $password = md5($pwd2);
            $query=mysqli_query($conn,"UPDATE tblregister SET Password='$password',Verification=1 WHERE User_Id=".$_SESSION['userId']." ;");

        if ($query) {
            $role = $_SESSION['Role'];
            if($role == "Admin"){
                echo "<script type = \"text/javascript\">
                    window.location = (\"Admin(directeur)/Admin/index.php \")
                    </script>";
            }
            else if($role == "Teacher"){
                
                echo "<script type = \"text/javascript\">
                    window.location = (\"Teacher/teacher/index.php \")
                    </script>";  
            }
            else if( $role == "Student"){
                echo "<script type = \"text/javascript\">
                    window.location = (\"Student/index.php \")
                    </script>";
            }else{

            }
            
        }else{
            echo '<style>
                #alert{
                    opacity: 0.9;
                }
                </style>';
                
          }
        }else{
            echo '<style>
                #alert{
                    opacity: 0.9;
                }
                </style>';
                
          }
        
    }


?>

                        <!-- Register buttons -->
                        <div class="text-center">
                         <span  style="font-family: Georgia, serif;font-size: 1.2em;color:#000;letter-spacing: 1px;" >
                         Get connected with us on social networks
                         </span>   
                        <button type="button"class="btn btn-link btn-floating mx-1">
                            <i style="font-size: 1.5em;" class="fab fa-facebook-f"></i>
                        </button>

                        <button type="button" class="btn btn-link btn-floating mx-1">
                            <i style="font-size: 1.5em;" class="fab fa-google"></i>
                        </button>

                        <button type="button" class="btn btn-link btn-floating mx-1">
                            <i style="font-size: 1.5em;" class="fab fa-twitter"></i>
                        </button>

                        <button type="button" class="btn btn-link btn-floating ">
                            <i style="font-size: 1.5em;" class="fab fa-github"></i>
                        </button>
                        </div>
                    </form>
                    </div>
                </div>
            </div>
            </section>
<!-- Section: Design Block -->
        <!---Container Fluid-->
      </div>
      <!-- Footer -->
      <?php // include "include/footer.php"; ?>
      <!-- Footer -->
    
  </div>
  <!-- Page level custom scripts -->
  <script>
      const pwShowHide = document.querySelectorAll(".eye-icon"),
            links = document.querySelectorAll(".link");
            
      pwShowHide.forEach(eyeIcon => {
          eyeIcon.addEventListener("click", () => {
              let pwFields = eyeIcon.parentElement.parentElement.querySelectorAll("#password");
              let pwFields1 = eyeIcon.parentElement.parentElement.querySelectorAll("#password1");
              pwFields.forEach(password => {
                  if(password.type === "password"){
                      password.type = "text";
                      eyeIcon.classList.replace("bx-hide", "bx-show");
                      return;
                  }
                  password.type = "password";
                  eyeIcon.classList.replace("bx-show", "bx-hide");
              })
              pwFields1.forEach(password => {
                  if(password.type === "password"){
                      password.type = "text";
                      eyeIcon.classList.replace("bx-hide", "bx-show");
                      return;
                  }
                  password.type = "password";
                  eyeIcon.classList.replace("bx-show", "bx-hide");
              })
              
          })
      }) 
      
      function verifi(){
        
        let pw1 = eyeIcon.parentElement.parentElement.querySelectorAll("#password").value;
        let pw2 = eyeIcon.parentElement.parentElement.querySelectorAll("#password1").value;
        if(pw1 != pw2){
            pw2.innerText = "";
            
        }
      }

  </script>
  <a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<div id="preloader"></div>

<!-- Vendor JS Files -->
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
<script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="assets/vendor/aos/aos.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>

<!-- Template Main JS File -->
<script src="assets/js/main.js"></script>

</body>

</html>
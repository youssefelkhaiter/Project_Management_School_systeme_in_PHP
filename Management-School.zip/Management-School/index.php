
 <!-- -->
 <?php
error_reporting(0);
// connection db 
include "database/db.php";
  // session start
  session_start();
  include "Session.php";


?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Home</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/university-student-graduation-png-22.png" rel="icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

</head>
<style>

  .navbar .active-Home {
    color: #fff;
  } 

</style>
<body>

  <!--  Header  -->
  <?php include 'Includes/header.php';?>
  <!-- End Header -->

  <!--  Hero Section  -->
  <section id="hero" class="hero d-flex align-items-center" style="background-image: url('assets/img/home7.jpg');background-size: cover;background-position: center;position: relative;">
    <div class="container">
      <div class="row gy-4 d-flex justify-content-between">
        <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center">
          <h2 data-aos="fade-up">Management School </h2>
          <p data-aos="fade-up" data-aos-delay="100">Welcome to Management School A leading institution for mastering project management skills,
             Unlock your potential in project management Acquire essential knowledge tools, and techniques, 
             Expert faculty and industry professionals Learn from seasoned practitioners and thought leaders.</p>

          <div class="btnlogin align-items-stretch mb-3" data-aos="fade-up" data-aos-delay="200">
            <a href="loginup.php" class="btn btn-primary" style="padding: 16px 28px;">Login up</a>
          </div>

          <div class="row gy-4" data-aos="fade-up" data-aos-delay="400">

            <div class="col-lg-3 col-6">
              <?php 
                $query1=mysqli_query($conn,"SELECT * from tblstudents");                       
                $students = mysqli_num_rows($query1);
              ?>
              <div class="stats-item text-center w-100 h-100">
                <span data-purecounter-start="0" data-purecounter-end="<?php echo $students;?>" data-purecounter-duration="1" class="purecounter"></span>
                <p>Students</p>
              </div>
            </div><!-- End Stats Item -->

            <?php 
              $query2=mysqli_query($conn,"SELECT * from tblclassteacher");                       
              $classTeacher = mysqli_num_rows($query2);
            ?>
            <div class="col-lg-3 col-6">
              <div class="stats-item text-center w-100 h-100">
                <span data-purecounter-start="0" data-purecounter-end="<?php echo $classTeacher;?>" data-purecounter-duration="1" class="purecounter"></span>
                <p>Teacher</p>
              </div>
            </div><!-- End Stats Item -->
            <?php 
              $query3=mysqli_query($conn,"SELECT * from tblclass");                       
              $class = mysqli_num_rows($query3);
            ?>
            <div class="col-lg-3 col-6">
              <div class="stats-item text-center w-100 h-100">
                <span data-purecounter-start="0" data-purecounter-end="<?php echo $class;?>" data-purecounter-duration="1" class="purecounter"></span>
                <p>Classes</p>
              </div>
            </div><!-- End Stats Item -->

            <?php 
              $query4=mysqli_query($conn,"SELECT * from tbladmin");                       
              $classAdmin = mysqli_num_rows($query4);
            ?>
            <div class="col-lg-3 col-6">
              <div class="stats-item text-center w-100 h-100">
                <span data-purecounter-start="0" data-purecounter-end="<?php echo $classAdmin;?>" data-purecounter-duration="1" class="purecounter"></span>
                <p>Directions</p>
              </div>
            </div><!-- End Stats Item -->

          </div>
        </div>

        <div class="col-lg-5 order-1 text-center order-lg-2 hero-img" data-aos="zoom-out">
           <img src="assets/img/university-student-graduation-png-22.png" class="img-fluid mb-3 mb-lg-0 h-90 w-90" alt="img"> <!-- ../img/g-->
        </div>

      </div>
    </div>
  </section>
  <!-- End Hero Section -->

  <main id="main">

    <!--  Featured Services Section  -->
    <section id="featured-services" class="featured-services">
      <div class="container">

        <div class="row gy-4">

          <div class="col-lg-3 col-md-6 service-item d-flex" data-aos="fade-up">
            <div class="icon flex-shrink-0"><i class="fa-solid fa-user-graduate"></i></div>
            <div>
              <h4 class="title">Higher education</h4>
              <p class="description">In collaboration with its partners, the Management School offers holders of Bac+2 and Bac+3 diplomas a range of training …</p>
              <a href="#" class="readmore stretched-link"><span>Learn More</span><i class="bi bi-arrow-right"></i></a>
            </div>
          </div>
          <!-- End Service Item -->

          <div class="col-lg-3 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="100">
            <div class="icon flex-shrink-0"><i class="fa-solid fa-award"></i></div>
            <div>
              <h4 class="title">Initial training</h4>
              <p class="description">The Management School trains technicians and specialized technicians (Bac+2), qualified and competent to meet the professional requirements …</p>
              <a href="#" class="readmore stretched-link"><span>Learn More</span><i class="bi bi-arrow-right"></i></a>
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-3 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="200">
            <div class="icon flex-shrink-0"><i class="fa-solid fa-certificate"></i></div>
            <div>
              <h4 class="title">Certificate</h4>
              <p class="description">Whether you want to improve your knowledge, career prospects, or resume, certification programs...</p>
              <a href="#" class="readmore stretched-link"><span>Learn More</span><i class="bi bi-arrow-right"></i></a>
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-3 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="200">
            <div class="icon flex-shrink-0"><i class="fa-solid fa-graduation-cap"></i></div>
            <div>
                <h4 class="title">Personalized training</h4>
                <p class="description">Management School offers you adapted solutions in terms of modular training that meets the needs of the job market and your expectations...</p>
                <a href="#" class="readmore stretched-link"><span>Learn More</span><i class="bi bi-arrow-right"></i></a>
            </div>
          </div><!-- End Service Item -->

        </div>

      </div>
    </section>
    <!-- End Featured Services Section -->

    <!-- ======= About Us Section ======= -->
    <section id="about" class="about pt-0">
      <div class="container" data-aos="fade-up">
        <div class="row gy-4">
          
          <div class="col-lg-6 content order-last  order-lg-first">
            <h3>About </h3>
            <p>
            Our faculty consists of seasoned project management practitioners and industry experts who bring a wealth of knowledge and 
            practical insights into the classroom. They guide students through interactive discussions, case studies, and hands-on exercises, 
            ensuring a valuable learning experience.
            </p>
            <ul>
              <li data-aos="fade-up" data-aos-delay="100">
              <i class="fa-solid fa-sitemap"></i>
                <div>
                  <h5>Efficient Project Management</h5>
                  <p> Our system provides a robust platform for efficient project management, enabling teams to plan, track, and collaborate effectively throughout the project lifecycle.</p>
                </div>
              </li>
              <li data-aos="fade-up" data-aos-delay="200">
              <i class="fa-solid fa-briefcase"></i>
              <!-- <i class="fa-solid fa-users"></i> -->
                <div>
                  <h5>Streamlined Workflow</h5>
                  <p> Our system simplifies project workflows by automating routine tasks, facilitating communication, and centralizing project documentation, resulting in improved productivity and reduced administrative overhead.</p>
                </div>
              </li>
              <li data-aos="fade-up" data-aos-delay="300">
              <i class="fa-solid fa-chart-column"></i>
                <div>
                  <h5>Data-driven Insights</h5>
                  <p> With our system, users gain valuable insights through comprehensive analytics and reporting, empowering them to make informed decisions, identify trends, and optimize project performance.</p>
                </div>
              </li>
            </ul>

          </div>
          <div class="col-lg-6 position-relative order-lg-last order-first"> <!-- align-self-start -->
            <img src="assets/img/school-management-system-png.png" class="img-fluid w-100 h-100" alt="image.img">
            <!-- <a href="https://www.youtube.com/watch?v=l4yVf28RfO4" class="glightbox play-btn"></a> -->
            <a href="https://www.youtube.com/watch?v=7f0wZw1b9ic" class="glightbox play-btn"></a>
          </div>
        </div>
      </div>
    </section>
    <!-- End About Us Section -->

    <!-- ======= Services Section ======= -->
    <section id="service" class="services pt-0">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <span>TRAINING CATEGORIES</span>
          <h2>TRAINING CATEGORIES</h2>

        </div>

        <div class="row gy-4">

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <div class="card">
              <div class="card-img">
                <img src="assets/img/Project-Management.jpg" alt="" class="img-fluid">
              </div>
              <h3><a href="#" class="stretched-link">Management</a></h3>
              <p>Preside over all the daily operations of a company in order to best guarantee its proper functioning, but also to ensure the highest level of efficiency and profitability of its business</p>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
            <div class="card">
              <div class="card-img">
                <img src="assets/img/comptabilite.jpg" alt="" class="img-fluid">
              </div>
              <h3><a href="#" class="stretched-link">Comptabilité</a></h3>
              <p>manage a company's accounts, accounts receivable, suppliers or payroll and more generally its financial health</p>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="300">
            <div class="card">
              <div class="card-img">
                <img src="assets/img/info.jpg" alt="" class="img-fluid">
              </div>
              <h3><a href="#" class="stretched-link">Computer science</a></h3>
              <p>Design or adapt existing technical solutions according to the project and the customer's request. (Sites, software, networks, software packages)</p>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="400">
            <div class="card">
              <div class="card-img">
                <img src="assets/img/quality.webp" alt="" class="img-fluid">
              </div>
              <h3><a href="#" class="stretched-link">Quality</a></h3>
              <p>Acquire the tools to implement a quality approach in a company that wishes to have continuous improvement in order to increase the quality of its production and its organization</p>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="500">
            <div class="card">
              <div class="card-img">
                <img src="assets/img/logistics.jpg" alt="" class="img-fluid">
              </div>
              <h3><a href="#" class="stretched-link">Logistic transport </a></h3>
              <p>Manage everything related to the transport and storage of the company's products: vehicles necessary for transport, company suppliers, warehouses, handling, etc., optimizing their circulation to minimize costs and delays</p>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="card">
              <div class="card-img">
                <img src="assets/img/Humanressources.jpeg" alt="" class="img-fluid">
              </div>
              <h3><a href="#" class="stretched-link">Human ressources</a></h3>
              <p>Manage everything related to social relations within the company, payroll, legal aspects, employment contracts... and on the other hand the development of human resources</p>
            </div>
          </div><!-- End Card Item -->

        </div>

      </div>
    </section>
    <!-- End Services Section -->

    <!-- ======= Call To Action Section ======= -->
    <section id="call-to-action" class="call-to-action">
      <div class="container" data-aos="zoom-out">

        <div class="row justify-content-center">
          <div class="col-lg-8 text-center">
            <h3>OUR TRAINING</h3>
            <p> Management School trains specialized, qualified and competent technicians to meet the professional requirements and the needs of companies.</p>
            <a class="cta-btn" href="#">OUR TRAINING</a>
          </div>
        </div>

      </div>
    </section><!-- End Call To Action Section -->

    <!-- ======= Features Section ======= -->
    <section id="features" class="features">
      <div class="container">

        <div class="row gy-4 align-items-center features-item" data-aos="fade-up">

          <div class="col-md-5">
            <img src="assets/img/training.webp" class="img-fluid" alt="image">
          </div>
          <div class="col-md-7">
            <h3>Professional training</h3>
            <p class="fst-italic">
                Management School offers diplomas accredited by the State and accessible to Bachelors, Graduates or trainees benefiting from the gateway system.
            </p>
            <ul>
              <li><i class="bi bi-check"></i> Up-to-date knowledge.</li>
              <li><i class="bi bi-check"></i> Practical application.</li>
              <li><i class="bi bi-check"></i> Continuous learning.</li>
            </ul>
          </div>
        </div>
        <!-- Features Item -->

        <div class="row gy-4 align-items-center features-item" data-aos="fade-up">
          <div class="col-md-5 order-1 order-md-2">
            <img src="assets/img/Higher-Education.jpg" class="img-fluid" alt="image">
          </div>
          <div class="col-md-7 order-2 order-md-1">
            <h3>Higher education</h3>
            <p class="fst-italic">
            Management School is a member of the FEDE and has the diplomas of the European bachelor (bac +3) and European master (bac +5).
            </p>
            <ul>
              <li><i class="bi bi-check"></i>Academic Excellence.</li>
              <li><i class="bi bi-check"></i>Career Preparation.</li>
              <li><i class="bi bi-check"></i>Personal Development.</li>
            </ul>
          </div>
        </div><!-- Features Item -->

        <div class="row gy-4 align-items-center features-item" data-aos="fade-up">
          <div class="col-md-5">
            <img src="assets/img/ContinuingEducation.jpg" class="img-fluid" alt="image">
          </div>
          <div class="col-md-7">
            <h3>Continuing Education</h3>
            <p>At the request of companies and individuals, Management School school can create and offer specific training, offers standard programs designed by professionals in the sector.</p>
            <ul>
              <li><i class="bi bi-check"></i>Lifelong Learning.</li>
              <li><i class="bi bi-check"></i>Skill Enhancement.</li>
              <li><i class="bi bi-check"></i>Career Advancement.</li>
            </ul>
          </div>
        </div><!-- Features Item -->

        <!-- <div class="row gy-4 align-items-center features-item" data-aos="fade-up">
          <div class="col-md-5 order-1 order-md-2">
            <img src="assets/img/features-4.jpg" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 order-2 order-md-1">
            <h3>Quas et necessitatibus eaque impedit ipsum animi consequatur incidunt in</h3>
            <p class="fst-italic">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
              magna aliqua.
            </p>
            <p>
              Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
              velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
              culpa qui officia deserunt mollit anim id est laborum
            </p>
          </div>
        </div> -->
        <!-- Features Item -->

      </div>
    </section><!-- End Features Section -->

    <!-- ======= Pricing Section ======= -->
    <section id="pricing" class="pricing pt-0">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <span>Pricing</span>
          <h2>Pricing</h2>

        </div>

        <div class="row gy-4">

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
            <div class="pricing-item">
              <h3>Professional training</h3>
              <h4><sup>DHs</sup>999.99<span> / month</span></h4>
              <ul>
                <li><i class="bi bi-check"></i> 2 Years</li>
                <li><i class="bi bi-check"></i> bac +2</li>
                <li><i class="bi bi-check"></i> Specialized technician</li>
                <!-- <li class="na"><i class="bi bi-x"></i> <span>Pharetra massa massa ultricies</span></li>
                <li class="na"><i class="bi bi-x"></i> <span>Massa ultricies mi quis hendrerit</span></li> -->
              </ul>
              <a href="#" class="buy-btn">Buy Now</a>
            </div>
          </div><!-- End Pricing Item -->

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <div class="pricing-item featured">
              <h3> Higher education</h3>
              <h4><sup>DHs</sup>1 999<span> / month</span></h4>
              <ul>
                <li><i class="bi bi-check"></i>3 Years </li>
                <li><i class="bi bi-check"></i> bac +5</li>
                <li><i class="bi bi-check"></i> Master</li>
                <!-- <li><i class="bi bi-check"></i> Pharetra massa massa ultricies</li>
                <li><i class="bi bi-check"></i> Massa ultricies mi quis hendrerit</li> -->
              </ul>
              <a href="#" class="buy-btn">Buy Now</a>
            </div>
          </div><!-- End Pricing Item -->

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="300">
            <div class="pricing-item">
              <h3> Continuing Education</h3>
              <h4><sup>DHs</sup>2 500<span> / month</span></h4>
              <ul>
                <li><i class="bi bi-check"></i>+5 Years</li>
                <li><i class="bi bi-check"></i>bac +8</li>
                <li><i class="bi bi-check"></i> Superior </li>
                <!-- <li><i class="bi bi-check"></i> Pharetra massa massa ultricies</li>
                <li><i class="bi bi-check"></i> Massa ultricies mi quis hendrerit</li> -->
              </ul>
              <a href="#" class="buy-btn">Buy Now</a>
            </div>
          </div><!-- End Pricing Item -->

        </div>

      </div>
    </section><!-- End Pricing Section -->

    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials">
      <div class="container">

        <div class="slides-1 swiper" data-aos="fade-up">
          <div class="swiper-wrapper">

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="assets/img/testimonials/istockphoto-1297174535-612x612.jpg" class="testimonial-img" alt="">
                <h3>Elkhaiter Youssef</h3>
                <h4>developer application desktop </h4>
                <div class="stars">
                  <i class="bi bi-star-fill"></i>
                  <i class="bi bi-star-fill"></i>
                  <i class="bi bi-star-fill"></i>
                  <i class="bi bi-star-fill"></i>
                  <i class="bi bi-star-fill"></i>
                </div>
                <p>
                  <i class="bi bi-quote quote-icon-left"></i>
                  Un développeur d'applications de bureau, quant à lui, se concentre sur la création d'applications logicielles qui s'exécutent sur des ordinateurs de bureau(Windows).
                  <i class="bi bi-quote quote-icon-right"></i>
                </p>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="assets/img/testimonials/istockphoto-1297174535-612x612.jpg" class="testimonial-img" alt="">
                <h3>Elkhaiter Youssef</h3>
                <h4>developer Web </h4>
                <div class="stars">
                  <i class="bi bi-star-fill"></i>
                  <i class="bi bi-star-fill"></i>
                  <i class="bi bi-star-fill"></i>
                  <i class="bi bi-star-fill"></i>
                  <i class="bi bi-star-fill"></i>
                </div>
                <p>
                  <i class="bi bi-quote quote-icon-left"></i>
                  Un développeur Web est un professionnel spécialisé dans la création de sites Web et d'applications Web.
                  <i class="bi bi-quote quote-icon-right"></i>
                </p>
              </div>
            </div><!-- End testimonial item -->
           
          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Testimonials Section -->

    <!-- End image Section -->
    <section >
      <div class="container">

        <div class="row gy-2">

          <div class="col-lg-3 col-md-6 service-item d-flex" data-aos="fade-up">
            <img src="assets/img/std1.jpg" class="img-fluid" style="height: 300px;" alt="...">
          </div>
          <!-- End Service Item -->

          <div class="col-lg-3 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="300">
            <img src="assets/img/std2.jpg" class="img-fluid" style="height: 300px;" alt="...">
          </div><!-- End Service Item -->

          <div class="col-lg-3 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="200">
            <img src="assets/img/std.png" class="img-fluid" style="height: 300px;" alt="...">
          </div><!-- End Service Item -->

          <div class="col-lg-3 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="400">
            <img src="assets/img/std4.avif" class="img-fluid" style="height: 300px;" alt="...">
          </div><!-- End Service Item -->

        </div>

      </div>
    </section><!-- End image Section -->

    <!-- ======= Frequently Asked Questions Section ======= -->
    <section id="faq" class="faq">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <span>FREQUENTLY ASKED QUESTIONS</span>
          <h2>FREQUENTLY ASKED QUESTIONS</h2>

        </div>

        <div class="row justify-content-center" data-aos="fade-up" data-aos-delay="200">
          <div class="col-lg-10">

            <div class="accordion accordion-flush" id="faqlist">

              <div class="accordion-item">
                <h3 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-1">
                    <i class="bi bi-question-circle question-icon"></i>
                    Non consectetur a erat nam at lectus urna duis?
                  </button>
                </h3>
                <div id="faq-content-1" class="accordion-collapse collapse" data-bs-parent="#faqlist">
                  <div class="accordion-body">
                    Feugiat pretium nibh ipsum consequat. Tempus iaculis urna id volutpat lacus laoreet non curabitur gravida. Venenatis lectus magna fringilla urna porttitor rhoncus dolor purus non.
                  </div>
                </div>
              </div><!-- # Faq item-->

              <div class="accordion-item">
                <h3 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-2">
                    <i class="bi bi-question-circle question-icon"></i>
                    Feugiat scelerisque varius morbi enim nunc faucibus a pellentesque?
                  </button>
                </h3>
                <div id="faq-content-2" class="accordion-collapse collapse" data-bs-parent="#faqlist">
                  <div class="accordion-body">
                    Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi. Id interdum velit laoreet id donec ultrices. Fringilla phasellus faucibus scelerisque eleifend donec pretium. Est pellentesque elit ullamcorper dignissim. Mauris ultrices eros in cursus turpis massa tincidunt dui.
                  </div>
                </div>
              </div><!-- # Faq item-->

              <div class="accordion-item">
                <h3 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-3">
                    <i class="bi bi-question-circle question-icon"></i>
                    Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi?
                  </button>
                </h3>
                <div id="faq-content-3" class="accordion-collapse collapse" data-bs-parent="#faqlist">
                  <div class="accordion-body">
                    Eleifend mi in nulla posuere sollicitudin aliquam ultrices sagittis orci. Faucibus pulvinar elementum integer enim. Sem nulla pharetra diam sit amet nisl suscipit. Rutrum tellus pellentesque eu tincidunt. Lectus urna duis convallis convallis tellus. Urna molestie at elementum eu facilisis sed odio morbi quis
                  </div>
                </div>
              </div><!-- # Faq item-->

              <div class="accordion-item">
                <h3 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-4">
                    <i class="bi bi-question-circle question-icon"></i>
                    Ac odio tempor orci dapibus. Aliquam eleifend mi in nulla?
                  </button>
                </h3>
                <div id="faq-content-4" class="accordion-collapse collapse" data-bs-parent="#faqlist">
                  <div class="accordion-body">
                    <i class="bi bi-question-circle question-icon"></i>
                    Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi. Id interdum velit laoreet id donec ultrices. Fringilla phasellus faucibus scelerisque eleifend donec pretium. Est pellentesque elit ullamcorper dignissim. Mauris ultrices eros in cursus turpis massa tincidunt dui.
                  </div>
                </div>
              </div><!-- # Faq item-->

              <div class="accordion-item">
                <h3 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-5">
                    <i class="bi bi-question-circle question-icon"></i>
                    Tempus quam pellentesque nec nam aliquam sem et tortor consequat?
                  </button>
                </h3>
                <div id="faq-content-5" class="accordion-collapse collapse" data-bs-parent="#faqlist">
                  <div class="accordion-body">
                    Molestie a iaculis at erat pellentesque adipiscing commodo. Dignissim suspendisse in est ante in. Nunc vel risus commodo viverra maecenas accumsan. Sit amet nisl suscipit adipiscing bibendum est. Purus gravida quis blandit turpis cursus in
                  </div>
                </div>
              </div><!-- # Faq item-->

            </div>

          </div>
        </div>

      </div>
    </section><!-- End Frequently Asked Questions Section -->

  </main><!-- End #main -->

  <!-- Footer -->
  <?php include 'Includes/footer.php';?>
  <!-- End Footer -->

  <a href="#" class="scroll-top d-flex align-items-center justify-content-center">
    <i class="bi bi-arrow-up-short"></i>
  </a>

  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>

<?php

if (isset($_COOKIE["Username"]) && isset($_COOKIE["Password"])) {

    $Username = $_COOKIE["Username"];//base64_decode($_COOKIE["Username"]);
    $Password = $_COOKIE["Password"];// base64_decode($_COOKIE["Password"]);

    // $password = md5($Password);

    $query = "SELECT * FROM tblregister WHERE Email = '$Username' AND Password = '$Password'"; 
    $rs = $conn->query($query);
    $num = $rs->num_rows;
    $row = $rs->fetch_assoc();

    if($num > 0){
        $role =  $row['Role'];
        $User_id = $row['User_Id'];

        // Admin 
        if($role == "Admin"){

            $qu = "SELECT * FROM tbladmin WHERE Id=$User_id ;";
            $rs = $conn->query($qu);
            $number = $rs->num_rows;
            $rows = $rs->fetch_assoc();
            if($number > 0){

              $_SESSION['userId'] = $rows['Id'];
              $_SESSION['firstName'] = $rows['firstName'];
              $_SESSION['lastName'] = $rows['lastName'];
              $_SESSION['emailAddress'] = $rows['emailAddress'];
              $_SESSION['Role'] = $role;
              $_SESSION['image_Id'] = $row['Id'];

                 echo "<script type = \"text/javascript\">
                       window.location = (\"Admin(directeur)/Admin/index.php\")
                       </script>";
            }
        }
        // Teacher
        if($role == "Teacher"){

          $qu = "SELECT * FROM tblclassteacher WHERE Id =$User_id ";
          $rs = $conn->query($qu);
          $number = $rs->num_rows;
          $rows = $rs->fetch_assoc();
          if($number > 0){
            $_SESSION['userId'] = $rows['Id'];
            $_SESSION['firstName'] = $rows['firstName'];
            $_SESSION['lastName'] = $rows['lastName'];
            $_SESSION['emailAddress'] = $rows['emailAddress'];
            $_SESSION['Role'] = $role;
            $_SESSION['image_Id'] = $row['Id'];

               echo "<script type = \"text/javascript\">
                     window.location = (\"Teacher/teacher/index.php \")
                        </script>";
            }
        }
        // Student
        if($role == "Student"){

            $qu = "SELECT * FROM tbladmin WHERE Id = '$User_id'";
            $rs = $conn->query($qu);
            $number = $rs->num_rows;
            $rows = $rs->fetch_assoc();
            if($number > 0){
            $_SESSION['userId'] = $rows['Id'];
            $_SESSION['firstName'] = $rows['firstName'];
            $_SESSION['lastName'] = $rows['lastName'];
            $_SESSION['emailAddress'] = $rows['emailAddress'];

                echo "<script type = \"text/javascript\">
                    window.location = (\" \")
                    </script>";
            }
        }

    }
}
    

?>

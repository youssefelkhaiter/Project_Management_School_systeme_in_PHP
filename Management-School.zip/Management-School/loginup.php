 <!-- -->
 <?php 
error_reporting(0);
  // connection db 
  include "database/db.php";
  // session start
  session_start();
  include "remember.php";
  include "Session.php";




?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Login up</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/university-student-graduation-png-22.png" rel="icon">
  <link href="assets/img/university-student-graduation-png-22.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
  
</head>
<style>
    .rounded-t-5 {
      border-top-left-radius: 0.5rem;
      border-top-right-radius: 0.5rem;
    }

    @media (min-width: 992px) {
      .rounded-tr-lg-0 {
        border-top-right-radius: 0;
      }

      .rounded-bl-lg-5 {
        border-bottom-left-radius: 0.5rem;
      }
    }
    #content-wrapper{
        height: 100vh;
    }
    #alert{
        opacity: 0.0;
    }
    .form-outline .field{
          position: relative;
          height: 50px;
          width: 100%;
          margin-top: 20px;
          border-radius: 6px;
      }
      .form-outline .field #input,
      .form-outline .field #password{
          height: 100%;
          width: 100%;
          border: none;
          font-size: 16px;
          font-weight: 400;
          border-radius: 6px;
      }
      .form-outline .field #input,
      .form-outline .field #password{
          outline: none;
          padding: 0 15px;
          border: 1px solid#CACACA;
      }
      .form-outline .field #input:focus,
      .form-outline .field #password:focus{
          border-bottom-width: 2px;
      }
      .form-outline .eye-icon{
          position: absolute;
          top: 50%;
          right: 10px;
          transform: translateY(-50%);
          font-size: 18px;
          color: #8b8b8b;
          cursor: pointer;
          padding: 5px;
      }
  </style>
<body id="page-top">
    <div id="content-wrapper" style="background-color: #003566;" class="d-flex flex-column">
      <div id="content" >
        <!-- TopBar -->
        <?php include "includes/header.php";?>
        <!-- Topbar -->
        <!-- ======= Breadcrumbs ======= -->
        <div class="breadcrumbs">
          <div class="page-header d-flex align-items-center" style="background-image: url('assets/img/cert2.webp');">
            <div class="container position-relative">
              <div class="row d-flex justify-content-center">
                <div class="col-lg-6 text-center">
                  <h2>Login up</h2>
                  <p>
                    <br>
                    <br>
                    <br>
                    <br>
                  </p>
                </div>
              </div>
            </div>
          </div>
          
        </div>
        <!-- End Breadcrumbs -->

        <!-- Section: Design Block -->
            <section class="text-center" >
            <!-- Background image -->
            
            </div>
            <!-- Background image -->

            <div class="card mx-4 mx-md-5 shadow-5-strong" style="
                    margin-top: -350px;
                    background: hsla(0, 0%, 100%, 0.6);
                    backdrop-filter: blur(30px);
                    ">
                <div class="card-body py-4 px-md-2">

                <div class="row d-flex justify-content-center">
                    <div class="col-lg-6">
                    <!-- <h2 class="fw-bold mb-3" style="font-family: Georgia, serif;font-size: 2.5em;letter-spacing: 2px;">Login up</h2> -->
                    <form method="POST">

                        <div class="form-outline mb-2">
                          <label class="form-label" style="font-family: Georgia, serif;font-size: 1.5em;letter-spacing: 1px;">Username</label>
                          <div class="field input-field mb-1">
                            <input type="email" id="input" name="email" placeholder="Enter Your Username" class="form-control" required />
                        </div>  
                        <!-- Password input -->
                        <div class="form-outline mb-2">
                          <label class="form-label" style="font-family: Georgia, serif;font-size: 1.5em;letter-spacing: 1px;">Password</label>
                          <div class="field input-field mb-1">
                              <input type="password" placeholder="Password" id="password" name="password" class="form-control" required />
                              <i class='bx bx-hide eye-icon'></i>
                          </div>
                        </div>
                        <!-- Checkbox -->
                        <div class="row mb-2">
                            <div class="col d-flex justify-content-center">
                                <!-- Checkbox -->
                                <div class="form-check">
                                  <input class="form-check-input" type="checkbox" value="RememberMe" name="remember" id="remember" />
                                  <label class="form-check-label" for="remember"> Remember me </label>
                                </div>
                            </div>

                            <div class="col">
                                <!-- Simple link -->
                                <a href="forgot.php">Forgot password?</a>
                            </div>
                        </div>

                        <!-- Submit button -->
                        <button type="submit" name="Loginup" style="font-family: Georgia, serif;font-size: 1.2em;letter-spacing: 2px;padding:5px 25px;"  class="btn btn-primary btn-block mb-2">
                        Login
                        </button>

                      <p class="alert alert-danger" id="alert" >
                          The Password Is Wrong
                      </p>

<?php 

if(isset($_POST['Loginup'])){

    if(isset($_POST['email']) && isset($_POST['password'])){

      $email = mysqli_real_escape_string($conn,$_POST['email']);
      $sampPass = mysqli_real_escape_string($conn,$_POST['password']); //$_POST['password'];
      $password = md5($sampPass);

      $query = "SELECT * FROM tblregister WHERE Email = '$email' AND Password = '$password' ;"; 
      $rs = $conn->query($query);
      $num = $rs->num_rows;
      $row = $rs->fetch_assoc();

      if($num > 0){
        
        // Remember User 
          if (isset($_POST["remember"])) {
              $remember = isset($_POST["remember"]);
              if ($remember == "RememberMe") {
                // $UsernameValue = base64_encode($email);
                // $PasswordValue = base64_encode($password); 
                
                $cookieExpiration = time() + (30 * 24 * 60 * 60); // Cookie expiration time (30 days)
                setcookie('Username', $email, $cookieExpiration);
                setcookie('Password', $password, $cookieExpiration);
                echo'<script>alert("Yes is Remember");</script>';
              }
          }

        $role =  $row['Role'];
        $User_id = $row['User_Id'];

        // Admin 
        if($role == "Admin"){

            $qu = "SELECT * FROM tbladmin WHERE Id =$User_id ";
            $rs = $conn->query($qu);
            $number = $rs->num_rows;
            $rows = $rs->fetch_assoc();
            if($number > 0){

              $_SESSION['userId'] = $rows['Id'];
              $_SESSION['firstName'] = $rows['firstName'];
              $_SESSION['lastName'] = $rows['lastName'];
              $_SESSION['emailAddress'] = $rows['emailAddress'];
              $_SESSION['Role'] = $role;
              $_SESSION['image_Id'] = $row['Id'];

              // $_SESSION['userId'] = $row['Id'];
              // $_SESSION['firstName'] = $row['Fname'];
              // $_SESSION['lastName'] = $row['Lname'];
              // $_SESSION['emailAddress'] = $row['Email'];
              // $_SESSION['Role'] = $row['Role'];
              // $_SESSION['image_Id'] = $row['Id'];
              
              if($row['Verification'] == 1){
                echo "<script type = \"text/javascript\">
                window.location = (\"Admin(directeur)/Admin/index.php\")
                </script>";
              }else{
                echo "<script type = \"text/javascript\">
                      window.location = (\"Verification.php \")
                      </script>";
              }
            }
        }
        // Teacher
        if($role == "Teacher"){

          $qu = "SELECT * FROM tblclassteacher WHERE Id =$User_id ";
          $rs = $conn->query($qu);
          $number = $rs->num_rows;
          $rows = $rs->fetch_assoc();
          if($number > 0){
            $_SESSION['userId'] = $rows['Id'];
            $_SESSION['firstName'] = $rows['firstName'];
            $_SESSION['lastName'] = $rows['lastName'];
            $_SESSION['emailAddress'] = $rows['emailAddress'];
            $_SESSION['Role'] = $role;
            $_SESSION['image_Id'] = $row['Id'];

            // $_SESSION['userId'] = $row['Id'];
            // $_SESSION['firstName'] = $row['Fname'];
            // $_SESSION['lastName'] = $row['Lname'];
            // $_SESSION['emailAddress'] = $row['Email'];
            // $_SESSION['Role'] = $row['Role'];
            // $_SESSION['image_Id'] = $row['Id'];

            if($row['Verification'] == 1){
              echo "<script type = \"text/javascript\">
              window.location = (\"Teacher/teacher/index.php \")
              </script>";
            }else{
              echo "<script type = \"text/javascript\">
                    window.location = (\"Verification.php \")
                    </script>";
            }
          }
      }
      // Student  	Student
      if($role == "Student"){

        $qu = "SELECT * FROM tblstudents WHERE Id=$User_id ;";
        $rs = $conn->query($qu);
        $number = $rs->num_rows;
        $rows = $rs->fetch_assoc();
        if($number > 0){
          $_SESSION['userId'] = $rows['Id'];
          $_SESSION['firstName'] = $rows['firstName'];
          $_SESSION['lastName'] = $rows['lastName'];
          $_SESSION['emailAddress'] = $rows['Email'];
          $_SESSION['Role'] = $role;
          $_SESSION['image_Id'] = $row['Id'];

          // $_SESSION['userId'] = $row['Id'];
          // $_SESSION['firstName'] = $row['Fname'];
          // $_SESSION['lastName'] = $row['Lname'];
          // $_SESSION['emailAddress'] = $row['Email'];
          // $_SESSION['Role'] = $row['Role'];
          // $_SESSION['image_Id'] = $row['Id'];
          
            if($row['Verification'] == 1){
              echo "<script type = \"text/javascript\">
              window.location = (\"Student/index.php \")
              </script>";
            }else{
              echo "<script type = \"text/javascript\">
                    window.location = (\"Verification.php \")
                    </script>";
            }
        }
    }

      }else{
        echo '<style>
            #alert{
                opacity: 0.9;
            }
            </style>';
            
      }

    }
    
}

?>

                        <!-- Register buttons -->
                        <div class="text-center">
                         <span  style="font-family: Georgia, serif;font-size: 1.2em;color:#000;letter-spacing: 1px;" >
                         Get connected with us on social networks
                         </span>   
                        <button type="button"class="btn btn-link btn-floating mx-1">
                            <i style="font-size: 1.5em;" class="fab fa-facebook-f"></i>
                        </button>

                        <button type="button" class="btn btn-link btn-floating mx-1">
                            <i style="font-size: 1.5em;" class="fab fa-google"></i>
                        </button>

                        <button type="button" class="btn btn-link btn-floating mx-1">
                            <i style="font-size: 1.5em;" class="fab fa-twitter"></i>
                        </button>

                        <button type="button" class="btn btn-link btn-floating ">
                            <i style="font-size: 1.5em;" class="fab fa-github"></i>
                        </button>
                        </div>
                    </form>
                    </div>
                </div>
            </div>
          </section>
      </div>
      <!-- Footer -->
      <?php // include "include/footer.php"; ?>
      <!-- Footer -->
    
  </div>
  <!-- Page level custom scripts -->
  <script>
    // $(document).ready(function () {
    //   $('#dataTable').DataTable(); // ID From dataTable
    //   $('#dataTableHover').DataTable(); // ID From dataTable with Hover
    // });
      const pwShowHide = document.querySelectorAll(".eye-icon"),
            links = document.querySelectorAll(".link");
            
      pwShowHide.forEach(eyeIcon => {
          eyeIcon.addEventListener("click", () => {
              let pwFields = eyeIcon.parentElement.parentElement.querySelectorAll("#password");
              
              pwFields.forEach(password => {
                  if(password.type === "password"){
                      password.type = "text";
                      eyeIcon.classList.replace("bx-hide", "bx-show");
                      return;
                  }
                  password.type = "password";
                  eyeIcon.classList.replace("bx-show", "bx-hide");
              })
              
          })
      })      

  </script>
  <a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<div id="preloader"></div>

<!-- Vendor JS Files -->
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
<script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="assets/vendor/aos/aos.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>

<!-- Template Main JS File -->
<script src="assets/js/main.js"></script>

</body>

</html>
<?php
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function

 use PHPMailer\PHPMailer\PHPMailer;
 use PHPMailer\PHPMailer\SMTP;
 use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

$mail = new PHPMailer(true);

try {
  
    //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'tt3486667@gmail.com';                     //SMTP username
    $mail->Password   = 'qutsvtejduzpechx';                               //SMTP password::qutsvtejduzpechx
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    // $mail->SMTPSecure = 'tls';     
    $mail->Port       = 465;                                  //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
 
    // $From = 'tt3486667@gmail.com';
    // $name = 'Ecole ....';

    // $TO = 'youaaefelkhaiter12@gmail.com';
    // $name1 = 'test1';  
    // //Recipients
    // $mail->setFrom($From, $name);
    // $mail->addAddress($TO, $name1 );     //Add a recipient
    // // $mail->addAddress('ellen@example.com');               //Name is optional
    // // $mail->addReplyTo('info@example.com', 'Information');
    // // $mail->addCC('cc@example.com');
    // // $mail->addBCC('bcc@example.com');

    // //Attachments
    // // $mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
    // // $mail->addAttachment('demo.zip', 'Demo Zip File');    //Optional name

    // //Content
    // $mail->isHTML(true);                                  //Set email format to HTML
    // $mail->Subject = 'Verification Code ';
    // //$mail->msgHTML(file_get_contents("email-content.html"), __DIR__);

    // $time = time();
    // $mail->Body ="Code is : ".$time."<br>Enter this's Message Code";
    // //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    // $mail->send();
    // //echo 'Message has been sent <br> '.$time;
    // echo '<p class="alert alert-danger" id="alert" >
    //             Message has been sent
    //       </p>';
    
    
   
} catch (Exception $e) {
    //echo "Message is not sent. Error is : {$mail->ErrorInfo}";
    
}
?>
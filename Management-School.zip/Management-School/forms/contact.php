<?php
  // connection db 
  // include "../database/db.php";

  // include "../email/index.php";
    // Replace contact@example.com with your real receiving email address
  //$receiving_email_address = 'youaaefelkhaiter12@gmail.com';

  // if( file_exists($php_email_form = '../email/vendor/autoload.php' )) {
  //   include( $php_email_form );
  // } else {
  //   die( 'Unable to load the "PHP Email Form" Library!');
  // }

  // $contact = new PHP_Email_Form;
  // $contact->ajax = true;

  //  $From = 'youssefelkhaiter10@gmail.com';
  //  $name = 'Ecole';

  //    $TO =  'tt3486667@gmail.com';//mysqli_real_escape_string($conn ,$_POST['email']); // $_POST['email']; //';
  //    $name1 = 'hhhh';  

  //    $mail->setFrom($From, $name);
  //    $mail->addAddress($TO, $name1 );              
  //    $mail->Subject = mysqli_real_escape_string($conn ,$_POST['message']);

  //    $mail->send();
    
    
  // $contact->to = $receiving_email_address;
  // $contact->from_name = $_POST['name'];
  // $contact->from_email = $_POST['email'];
  // $contact->subject = $_POST['subject'];

  // Uncomment below code if you want to use SMTP to send emails. You need to enter your correct SMTP credentials
  /*
  $contact->smtp = array(
    'host' => 'example.com',
    'username' => 'example',
    'password' => 'pass',
    'port' => '587'
  );
  */

  // $contact->add_message( $_POST['name'], 'From');
  // $contact->add_message( $_POST['email'], 'Email');
  // $contact->add_message( $_POST['message'], 'Message', 10);
  // mysqli_real_escape_string($conn,$_POST['subject']);

  // echo $contact->send();
?>
<?php

// connection db 
include "../database/db.php";

if(isset($_POST['SendGmail'])){

  if(isset($_POST['email']) ){

    // $email = mysqli_real_escape_string($conn,$_POST['email']);

    // $query = "SELECT * FROM tblregister WHERE Email = '$email' "; 
    // $rs = $conn->query($query);
    // $num = $rs->num_rows;
    // $rows = $rs->fetch_assoc();

    if($num > 0)
    {

      include "../email/index.php";
      
      if(isset($_POST['forgot'])){

        $From = 'Management-School@gmail.com';
        $name = mysqli_real_escape_string($conn,$_POST['name']);

        $email = mysqli_real_escape_string($conn,$_POST['email']); // $email
        // $fullname = mysqli_real_escape_string($conn,$rows['Fname'].' , '.$rows['Lname']);  
        //Recipients
        $mail->setFrom($email , $name);
        $mail->addAddress('youaaefelkhaiter12@gmail.com',"Admin");     //Add a recipient

        //Content
        $mail->isHTML(true);                                  //Set email format to HTML
        $mail->Subject = mysqli_real_escape_string($conn,$_POST['subject']);
        //$mail->msgHTML(file_get_contents("email-content.html"), __DIR__);

        //$time = time();
        $mail->Body =mysqli_real_escape_string($conn,$_POST['message']);
        //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

        
        if($mail->send()){

          // // UPDATE `tblregister` SET `veri_code` = '11' WHERE tblregister. Id = 1;
          // $query_check_email = "UPDATE tblregister SET veri_code = $time WHERE Email = '$email' "; 
          // $rs_email = $conn->query($query_check_email);

          // if($rs_email){
            echo '<p  class="alert alert-primary" role="alert"  >
                      Message has been sent checked your Email
                </p>';
          // }
        }else{
          echo '<p class="alert alert-danger" >
                  Message is not sent. Error is : '.$mail->ErrorInfo.'
                </p>';
        }
        
      }
    }
  }
}

?>
 
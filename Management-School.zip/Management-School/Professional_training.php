<!-- -->
<?php
  error_reporting(0);
  // connection db 
  include "database/db.php";
    // session start
    session_start();
    include "Session.php";
  
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Services</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/university-student-graduation-png-22.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    rel="stylesheet"
    />
    <!-- Google Fonts -->
    <link
    href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
    rel="stylesheet"
    />
    <!-- MDB -->
    <link
    href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.0/mdb.min.css"
    rel="stylesheet"
    />

</head>
<style>

  .navbar .active-Trainings {
    color: #fff;
  } 

</style>

<body>

  <!-- ======= Header ======= -->
  <?php include 'Includes/header.php';?>
  <!-- End Header -->

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <div class="breadcrumbs">
      <div class="page-header d-flex align-items-center" style="background-image: url('assets/img/std2.jpg');">
        <div class="container position-relative">
          <div class="row d-flex justify-content-center">
            <div class="col-lg-8 text-center">
              <h2>Professional training</h2>
              <p>
              Management School offers diplomas accredited by the State and accessible to Bachelors, Graduates or trainees benefiting from the gateway system.
              </p>
            </div>
            <div class="col-lg-4 order-1 text-center order-lg-2" data-aos="zoom-out">
                <img src="assets/img/accredite.png" width="200px" height="200px" class="img-fluid mb-3 mb-lg-0 " alt="img"> <!-- ../img/g-->
            </div>

          </div>
        </div>
      </div>
      <nav>
        <div class="container">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li>Professional training</li>
          </ol>
        </div>
      </nav>
    </div>
    <!-- End Breadcrumbs -->
    <section class="pricing">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <span>Training course</span>
          <h2>Training course</h2>
        </div>

        <div class="row gy-4">

        <div class="accordion" id="accordionExampleY">
          
          <div class="accordion-item">
            <h2 class="accordion-header" id="headingTwoY0">
              <button class="accordion-button collapsed" type="button" data-mdb-toggle="collapse"
                data-mdb-target="#collapseTwoY0" aria-expanded="false" aria-controls="collapseTwoY0">
                <i class="fa-solid fa-code" style="margin-right: 10px;"></i>IT development
              </button>
            </h2>
            <div id="collapseTwoY0" class="accordion-collapse collapse" aria-labelledby="headingTwoY0"
              data-mdb-parent="#accordionExampleY">
              <div class="accordion-body">
              The analyst-programmer participates in the design of computer programs that he must adapt or modify according to the requests and needs expressed by their users.
              
              </div>
            </div>
          </div>

          <div class="accordion-item">
            <h2 class="accordion-header" id="headingTwoY">
              <button class="accordion-button collapsed" type="button" data-mdb-toggle="collapse"
                data-mdb-target="#collapseTwoY" aria-expanded="false" aria-controls="collapseTwoY">
                <i class="fa-solid fa-server" style="margin-right: 10px;"></i>Systems and Networks
              </button>
            </h2>
            <div id="collapseTwoY" class="accordion-collapse collapse" aria-labelledby="headingTwoY"
              data-mdb-parent="#accordionExampleY">
              <div class="accordion-body">
                Responsible for improving the flow of information within the company's computer network, i.e. between the different people using a computer. The company's employees must, in fact, have access to information at all times and be able to share it.
              </div>
            </div>
          </div>

          <div class="accordion-item">
            <h2 class="accordion-header" id="headingThreeY">
              <button class="accordion-button collapsed" type="button" data-mdb-toggle="collapse"
                data-mdb-target="#collapseThreeY" aria-expanded="false" aria-controls="collapseThreeY">
                <i class="fa-solid fa-business-time" style="margin-right: 10px;"></i>Business Management
              </button>
            </h2>
            <div id="collapseThreeY" class="accordion-collapse collapse" aria-labelledby="headingThreeY"
              data-mdb-parent="#accordionExampleY">
              <div class="accordion-body">
                Participate in the organization and development of a company by contributing to the achievement of several tasks.
                It is a versatile profession that is interested in the management of administrative, legal, accounting and tax files.
              </div>
            </div>
          </div>
        </div>

        </div>

      </div>
    </section>


    <section id="features" class="features">
      <div class="container">
      <div class="section-header">
          <span>Details training</span>
          <h2>Details training</h2>
      </div>

        <div class="row gy-4 features-item" data-aos="fade-up">

          <div class="col-md-5">
            <img src="assets/img/developpeur_multimedia.png" style="height: 400px;" class="img-fluid" alt="image">
          </div>
          <div class="col-md-7">
            <h3>IT DEVELOPMENT Specialized Technician Diploma</h3>
            <p class="fst-italic">
            <span style="font-weight: 700; font-size: 20px;">Professional objectives:</span> Develop and use computer applications in management, apply basic management procedures, contribute to the main functions of the company, use various business information systems for the proposal of computer solutions, create and operate databases for management and office automation.<br>
            <span style="font-weight: 700; font-size: 20px;">Duration of training:</span> With Bac level or with DQ.
            </p> 

            <div class="col-lg-12">
                <div class="accordion accordion-borderless" id="accordionFlushExampleX1">
                    
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="flush-headingThreeX1">
                        <button class="accordion-button collapsed" type="button" data-mdb-toggle="collapse"
                            data-mdb-target="#flush-collapseThreeX1" aria-expanded="false" aria-controls="flush-collapseThreeX1">
                            <span style="font-weight: 600; font-size: 18px;">Training program: 1st year</span>
                        </button>
                        </h2>
                        <div id="flush-collapseThreeX1" class="accordion-collapse collapse" aria-labelledby="flush-headingThreeX1"
                        data-mdb-parent="#accordionFlushExampleX1">
                        <div class="accordion-body">
                        <ul>
                            <li><i class="bi bi-check"></i>Métier et formation.</li>
                            <li><i class="bi bi-check"></i>L’entreprise et son environnement</li>
                            <li><i class="bi bi-check"></i>Notions de mathématiques appliquées à l'informatique</li>
                            <li><i class="bi bi-check"></i>Techniques de programmation structurée</li>
                            <li><i class="bi bi-check"></i>Langage de programmation structurée</li>
                            <li><i class="bi bi-check"></i>Logiciels d’application</li>
                            <li><i class="bi bi-check"></i>Gestion du temps</li>
                            <li><i class="bi bi-check"></i>Installation d’un poste informatique</li>
                            <li><i class="bi bi-check"></i>Introduction aux réseaux informatiques</li>
                            <li><i class="bi bi-check"></i>Programmation événementielle</li>
                            <li><i class="bi bi-check"></i>Système d’exploitation « open source »</li>
                            <li><i class="bi bi-check"></i>Production de documents</li>
                            <li><i class="bi bi-check"></i>Communication interpersonnelle</li>
                            <li><i class="bi bi-check"></i>Communication en anglais dans un contexte de travail</li>
                            <li><i class="bi bi-check"></i>Soutien technique en milieu de travail (Stage I)</li>
                            <li><i class="bi bi-check"></i>Projet de fin d’année</li>

                        </ul>
                        </div>
                        </div>
                    </div>

                    <div class="accordion-item">
                        <h2 class="accordion-header" id="flush-headingTwoX1">
                        <button class="accordion-button collapsed" type="button" data-mdb-toggle="collapse"
                            data-mdb-target="#flush-collapseTwoX1" aria-expanded="false" aria-controls="flush-collapseTwoX1">
                            <span style="font-weight: 600; font-size: 18px;">Training program: 2nd year</span>
                        </button>
                        </h2>
                        <div id="flush-collapseTwoX1" class="accordion-collapse collapse" aria-labelledby="flush-headingTwoX1"
                        data-mdb-parent="#accordionFlushExampleX1">
                        <div class="accordion-body">
                        <ul>
                            <li><i class="bi bi-check"></i>Conception et modélisation d’un système d’information</li>
                            <li><i class="bi bi-check"></i>Initiation à la gestion de projets informatiques</li>
                            <li><i class="bi bi-check"></i>Système de gestion de bases de données</li>
                            <li><i class="bi bi-check"></i>Analyse et conception orientée objet</li>
                            <li><i class="bi bi-check"></i>Programmation Client-serveur</li>
                            <li><i class="bi bi-check"></i>Assistance technique à la clientèle</li>
                            <li><i class="bi bi-check"></i>Programmation orientée objet</li>
                            <li><i class="bi bi-check"></i>Déploiement d’applications</li>
                            <li><i class="bi bi-check"></i>Applications hypermédias</li>
                            <li><i class="bi bi-check"></i>Programmation de sites Web dynamiques</li>
                            <li><i class="bi bi-check"></i>Projet de conception de fin de formation</li>
                            <li><i class="bi bi-check"></i>Recherche d’emploi</li>
                            <li><i class="bi bi-check"></i> Intégration au milieu du travail (Stage II)</li>
                        </ul>
                        </div>
                        </div>
                    </div>
                    
                </div>
           </div>
          </div>
        </div>
        
        <div class="row gy-4 align-items-center features-item" data-aos="fade-up">
          <div class="col-md-5 order-1 order-md-2">
            <img src="assets/img/business-management.jpg" style="height: 400px;" class="img-fluid" alt="image">
          </div>
          <div class="col-md-7 order-2 order-md-1">
            <h3>Diploma of Specialized Technician BUSINESS MANAGEMENT</h3>
            <p class="fst-italic">
            <span style="font-weight: 700; font-size: 20px;">Professional objectives:</span>  To integrate harmoniously into the workplace, To apply the principles and methods essential to the practice of the trade, To use computer tools, To communicate in the workplace, To carry out technical tasks in business management and accounting.
            <span style="font-weight: 700; font-size: 20px;">Duration of training:</span> 2 years with Bac (or more) or with DT, 1 year with Licence.
            </p>
            <div class="col-lg-12">
                <div class="accordion accordion-borderless" id="accordionFlushExampleX2">
                    
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="flush-headingThreeX2">
                        <button class="accordion-button collapsed" type="button" data-mdb-toggle="collapse"
                            data-mdb-target="#flush-collapseThreeX2" aria-expanded="false" aria-controls="flush-collapseThreeX2">
                            <span style="font-weight: 600; font-size: 18px;">Training program: 1st year</span>
                        </button>
                        </h2>
                        <div id="flush-collapseThreeX2" class="accordion-collapse collapse" aria-labelledby="flush-headingThreeX2"
                        data-mdb-parent="#accordionFlushExampleX2">
                        <div class="accordion-body">
                        <ul>
                            <li><i class="bi bi-check"></i>Métier et Formation</li>
                            <li><i class="bi bi-check"></i>Comptabilité Générale</li>
                            <li><i class="bi bi-check"></i>Mathématiques Financières</li>
                            <li><i class="bi bi-check"></i>Statistiques</li>
                            <li><i class="bi bi-check"></i>Marketing</li>
                            <li><i class="bi bi-check"></i>Gestion des Ressources Humaines</li>
                            <li><i class="bi bi-check"></i>Outils Bureautiques</li>
                            <li><i class="bi bi-check"></i>Législation de Travail</li>
                            <li><i class="bi bi-check"></i>L’environnement de l’entreprise</li>
                            <li><i class="bi bi-check"></i>Internet</li>
                            <li><i class="bi bi-check"></i> Communication en Français</li>
                            <li><i class="bi bi-check"></i>Communication en Anglais</li>
                            <li><i class="bi bi-check"></i>Soutien Technique en Milieu de Travail (Stage I)</li>
                            <li><i class="bi bi-check"></i>Projet de Fin d'Année</li>
                        </ul>
                        </div>
                        </div>
                    </div>

                    <div class="accordion-item">
                        <h2 class="accordion-header" id="flush-headingTwoX2">
                        <button class="accordion-button collapsed" type="button" data-mdb-toggle="collapse"
                            data-mdb-target="#flush-collapseTwoX2" aria-expanded="false" aria-controls="flush-collapseTwoX2">
                            <span style="font-weight: 600; font-size: 18px;">Training program: 2nd year</span>
                        </button>
                        </h2>
                        <div id="flush-collapseTwoX2" class="accordion-collapse collapse" aria-labelledby="flush-headingTwoX2"
                        data-mdb-parent="#accordionFlushExampleX2">
                        <div class="accordion-body">
                        <ul>
                            <li><i class="bi bi-check"></i>Comptabilité Analytique</li>
                            <li><i class="bi bi-check"></i>Gestion Budgétaire</li>
                            <li><i class="bi bi-check"></i>Paie et déclaration fiscale et sociale</li>
                            <li><i class="bi bi-check"></i>Logiciels de gestion</li>
                            <li><i class="bi bi-check"></i>Stratégie</li>
                            <li><i class="bi bi-check"></i>Diagnostic financier</li>
                            <li><i class="bi bi-check"></i>Diagnostic Marketing</li>
                            <li><i class="bi bi-check"></i>Gestion de la production et des approvisionnements</li>
                            <li><i class="bi bi-check"></i>Tableaux de bord</li>
                            <li><i class="bi bi-check"></i>Techniques de Recherche d'Emploi</li>
                            <li><i class="bi bi-check"></i>Bases de Données</li>
                            <li><i class="bi bi-check"></i>Programmation Web</li>
                            <li><i class="bi bi-check"></i>Communication Professionnelle en Français</li>
                            <li><i class="bi bi-check"></i>Anglais technique</li>
                            <li><i class="bi bi-check"></i>Projet de fin de formation</li>
                            <li><i class="bi bi-check"></i>Intégration en Milieu du Travail (Stage II)

                        </li>
                        </ul>
                        </div>
                        </div>
                    </div>
                    
                </div>
           </div>

          </div>
        </div><!-- Features Item -->

        <div class="row gy-4 align-items-center features-item" data-aos="fade-up">

          <div class="col-md-5">
            <img src="assets/img/systemes_reseaux.webp" style="height: 400px;" class="img-fluid" alt="image">
          </div>
          <div class="col-md-7">
            <h3>Network Systems Specialized Technician Diploma</h3>
            <p class="fst-italic">
            <span style="font-weight: 700; font-size: 20px;">Professional objectives:</span> Develop and use computer applications in management, apply basic management procedures, contribute to the main functions of the company, use various business information systems for the proposal of computer solutions, create and operate databases for management and office automation.<br>
            <span style="font-weight: 700; font-size: 20px;">Duration of training:</span> With Bac level or with DQ.
            </p> 

            <div class="col-lg-12">
                <div class="accordion accordion-borderless" id="accordionFlushExampleX">
                    
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="flush-headingThreeX">
                        <button class="accordion-button collapsed" type="button" data-mdb-toggle="collapse"
                            data-mdb-target="#flush-collapseThreeX" aria-expanded="false" aria-controls="flush-collapseThreeX">
                            <span style="font-weight: 600; font-size: 18px;">Training program: 1st year</span>
                        </button>
                        </h2>
                        <div id="flush-collapseThreeX" class="accordion-collapse collapse" aria-labelledby="flush-headingThreeX"
                        data-mdb-parent="#accordionFlushExampleX">
                        <div class="accordion-body">
                        <ul>
                            <li><i class="bi bi-check"></i>Métier et formation</li>
                            <li><i class="bi bi-check"></i>L’entreprise et son environnement</li>
                            <li><i class="bi bi-check"></i>Notions de mathématiques appliquées à l'informatique</li>
                            <li><i class="bi bi-check"></i>Techniques de programmation structurée</li>
                            <li><i class="bi bi-check"></i>Langage de programmation structurée</li>
                            <li><i class="bi bi-check"></i>Logiciels d’application</li>
                            <li><i class="bi bi-check"></i>Gestion du temps</li>
                            <li><i class="bi bi-check"></i>Installation d’un poste informatique</li>
                            <li><i class="bi bi-check"></i>Introduction aux réseaux informatiques</li>
                            <li><i class="bi bi-check"></i>Programmation événementielle</li>
                            <li><i class="bi bi-check"></i>Système d’exploitation « open source »</li>
                            <li><i class="bi bi-check"></i>Production de documents</li>
                            <li><i class="bi bi-check"></i>Communication interpersonnelle</li>
                            <li><i class="bi bi-check"></i>Communication en anglais dans un contexte de travail</li>
                            <li><i class="bi bi-check"></i>Soutien technique en milieu de travail (Stage I)</li>
                            <li><i class="bi bi-check"></i>Projet de fin d’année</li>

                        </ul>
                        </div>
                        </div>
                    </div>

                    <div class="accordion-item">
                        <h2 class="accordion-header" id="flush-headingTwoX">
                        <button class="accordion-button collapsed" type="button" data-mdb-toggle="collapse"
                            data-mdb-target="#flush-collapseTwoX" aria-expanded="false" aria-controls="flush-collapseTwoX">
                            <span style="font-weight: 600; font-size: 18px;">Training program: 2nd year</span>
                        </button>
                        </h2>
                        <div id="flush-collapseTwoX" class="accordion-collapse collapse" aria-labelledby="flush-headingTwoX"
                        data-mdb-parent="#accordionFlushExampleX">
                        <div class="accordion-body">
                        <ul>
                            <li><i class="bi bi-check"></i>Conception et modélisation d’un système d’information</li>
                            <li><i class="bi bi-check"></i>Initiation à la gestion de projets informatiques</li>
                            <li><i class="bi bi-check"></i>Système de gestion de bases de données</li>
                            <li><i class="bi bi-check"></i>Analyse et conception orientée objet</li>
                            <li><i class="bi bi-check"></i>Programmation Client-serveur</li>
                            <li><i class="bi bi-check"></i>Assistance technique à la clientèle</li>
                            <li><i class="bi bi-check"></i>Programmation orientée objet</li>
                            <li><i class="bi bi-check"></i>Déploiement d’applications</li>
                            <li><i class="bi bi-check"></i>Applications hypermédias</li>
                            <li><i class="bi bi-check"></i>Programmation de sites Web dynamiques</li>
                            <li><i class="bi bi-check"></i>Projet de conception de fin de formation</li>
                            <li><i class="bi bi-check"></i>Recherche d’emploi</li>
                            <li><i class="bi bi-check"></i> Intégration au milieu du travail (Stage II)</li>
                        </ul>
                        </div>
                        </div>
                    </div>
                    
                </div>
           </div>
          </div>
        </div>

      </div>
    </section>
    <!-- ======= Frequently Asked Questions Section ======= -->
    <section id="faq" class="faq">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <span>Frequently Asked Questions</span>
          <h2>Frequently Asked Questions</h2>

        </div>

        <div class="row justify-content-center" data-aos="fade-up" data-aos-delay="200">
          <div class="col-lg-10">

            <div class="accordion accordion-flush" id="faqlist">

              <div class="accordion-item">
                <h3 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-1">
                    <i class="bi bi-question-circle question-icon"></i>
                    Non consectetur a erat nam at lectus urna duis?
                  </button>
                </h3>
                <div id="faq-content-1" class="accordion-collapse collapse" data-bs-parent="#faqlist">
                  <div class="accordion-body">
                    Feugiat pretium nibh ipsum consequat. Tempus iaculis urna id volutpat lacus laoreet non curabitur gravida. Venenatis lectus magna fringilla urna porttitor rhoncus dolor purus non.
                  </div>
                </div>
              </div><!-- # Faq item-->

              <div class="accordion-item">
                <h3 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-2">
                    <i class="bi bi-question-circle question-icon"></i>
                    Feugiat scelerisque varius morbi enim nunc faucibus a pellentesque?
                  </button>
                </h3>
                <div id="faq-content-2" class="accordion-collapse collapse" data-bs-parent="#faqlist">
                  <div class="accordion-body">
                    Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi. Id interdum velit laoreet id donec ultrices. Fringilla phasellus faucibus scelerisque eleifend donec pretium. Est pellentesque elit ullamcorper dignissim. Mauris ultrices eros in cursus turpis massa tincidunt dui.
                  </div>
                </div>
              </div><!-- # Faq item-->

              <div class="accordion-item">
                <h3 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-3">
                    <i class="bi bi-question-circle question-icon"></i>
                    Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi?
                  </button>
                </h3>
                <div id="faq-content-3" class="accordion-collapse collapse" data-bs-parent="#faqlist">
                  <div class="accordion-body">
                    Eleifend mi in nulla posuere sollicitudin aliquam ultrices sagittis orci. Faucibus pulvinar elementum integer enim. Sem nulla pharetra diam sit amet nisl suscipit. Rutrum tellus pellentesque eu tincidunt. Lectus urna duis convallis convallis tellus. Urna molestie at elementum eu facilisis sed odio morbi quis
                  </div>
                </div>
              </div><!-- # Faq item-->

              <div class="accordion-item">
                <h3 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-4">
                    <i class="bi bi-question-circle question-icon"></i>
                    Ac odio tempor orci dapibus. Aliquam eleifend mi in nulla?
                  </button>
                </h3>
                <div id="faq-content-4" class="accordion-collapse collapse" data-bs-parent="#faqlist">
                  <div class="accordion-body">
                    <i class="bi bi-question-circle question-icon"></i>
                    Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi. Id interdum velit laoreet id donec ultrices. Fringilla phasellus faucibus scelerisque eleifend donec pretium. Est pellentesque elit ullamcorper dignissim. Mauris ultrices eros in cursus turpis massa tincidunt dui.
                  </div>
                </div>
              </div><!-- # Faq item-->

              <div class="accordion-item">
                <h3 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-5">
                    <i class="bi bi-question-circle question-icon"></i>
                    Tempus quam pellentesque nec nam aliquam sem et tortor consequat?
                  </button>
                </h3>
                <div id="faq-content-5" class="accordion-collapse collapse" data-bs-parent="#faqlist">
                  <div class="accordion-body">
                    Molestie a iaculis at erat pellentesque adipiscing commodo. Dignissim suspendisse in est ante in. Nunc vel risus commodo viverra maecenas accumsan. Sit amet nisl suscipit adipiscing bibendum est. Purus gravida quis blandit turpis cursus in
                  </div>
                </div>
              </div><!-- # Faq item-->

            </div>

          </div>
        </div>

      </div>
    </section><!-- End Frequently Asked Questions Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php include 'Includes/footer.php';?>
  <!-- End Footer -->

  <a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <div id="preloader"></div>
    <!-- MDB -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.0/mdb.min.js"></script>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>